/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan4;

/**
 *
 * @author ADAM
 */
import javax.swing.*;
import java.awt.event.*;

public abstract class Latihan4 implements ActionListener{

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI(){
        JFrame frame = new JFrame("Bertambah");
        //buat frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20,30,300,150);
        frame.getContentPane().setLayout(null);
        //Buat tombol
        JButton butt = new JButton("Klik Disini");
        frame.getContentPane().add(butt);
        butt.setBounds(20,30,200,20);
        //membuat instance objek aplikasi
        Latihan4 app = new Latihan4() {};
        //make the label
        app.label = new JLabel("clicks=0");
        app.label.setBounds(20,50,200,20);
        frame.getContentPane().add(app.label);
        
        butt.addActionListener(app);
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        clickCount++;
        label.setText("clicks="+clickCount);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                createAndShowGUI();
            }
        });
    }
    int clickCount=0;
    JLabel label;   
}
